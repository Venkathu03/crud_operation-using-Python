from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
import os
app = Flask(__name__)
app.secret_key = 'many random bytes'
cnx = mysql.connector.connect(
    user='Venky',
    password='Venky@2023',
    host='localhost',
    port='3307',
    database='practice',
    auth_plugin='mysql_native_password'
)
cursor = cnx.cursor()

# app = Flask(__name__)

@app.route('/')
def myFunc():
    cur = cnx.cursor()
    cur.execute("SELECT * FROM employees")
    data = cur.fetchall()
    cur.close()
    return render_template("main.html", employees = data)

@app.route("/home", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        flash("Data Inserted Successfully")
        Name = request.form["name"]
        Age = request.form["age"]
        Email = request.form["mail"]
        Contact = request.form["contact"]
        Designation = request.form["designation"]

        sql = "INSERT INTO employees (Name, Age, Email, Phone, Designation) VALUES (%s, %s, %s, %s, %s)"
        val = (Name, Age, Email, Contact, Designation)
        cursor.execute(sql, val)
        cnx.commit()
        return redirect(url_for('myFunc'))
    # else:
    #     return "error"
    # return render_template("main.html")


@app.route('/update',methods=['POST','GET'])
def update():

    if request.method == 'POST':
        flash("Updated Successfully")
        id_data = request.form["id"]
        Name = request.form["name"]
        Age = request.form["age"]
        Mail = request.form["mail"]
        Contact = request.form["contact"]
        Designation = request.form["designation"]
        # cur = cnx.cursor()
        cursor.execute(" UPDATE employees SET Name=%s, Age=%s, Email=%s, Phone=%s, Designation=%s WHERE Id=%s", (Name, Age, Mail, Contact, Designation, id_data))
        # flash("Data Updated Successfully")
        cnx.commit()
        return redirect(url_for('myFunc'))
    else:
        return "error"
    return render_template("main.html")

@app.route('/delete/<string:id_data>', methods=['POST','GET'])
def delete(id_data):

    # cur = mysql.connector.cursour()
    flash("Deleted Successfully")
    cursor.execute("DELETE FROM employees WHERE Id = %s", (id_data,))
    cnx.commit()
    return redirect(url_for('myFunc'))


if __name__ == "__main__":
    app.run(debug=True)